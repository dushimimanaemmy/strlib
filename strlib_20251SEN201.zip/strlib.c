
#include <stdio.h>
#include <stddef.h>

/* =====================================================
   HELPER FUNCTIONS
   ===================================================== */

/* Calculate string length without using strlen */
static size_t my_strlen(const char *s)
{
    size_t length;

    length = 0;

    while (*s != '\0')
    {
        length++;
        s++;
    }

    return length;
}

/* Convert uppercase ASCII to lowercase */
static char my_lower(char c)
{
    if (c >= 'A' && c <= 'Z')
    {
        return (char)(c + ('a' - 'A'));
    }

    return c;
}

/* Check whether needle matches at hay */
static int matches_at(const char *hay, const char *needle)
{
    while (*needle != '\0')
    {
        if (*hay != *needle)
        {
            return 0;
        }

        hay++;
        needle++;
    }

    return 1;
}


/* =====================================================
   FUNCTION 1: STR_FIND_CHAR
   ===================================================== */

const char *str_find_char(const char *s, char c)
{
    while (1)
    {
        if (*s == c)
        {
            return s;
        }

        if (*s == '\0')
        {
            return NULL;
        }

        s++;
    }
}


/* =====================================================
   FUNCTION 2: STR_REVERSE
   ===================================================== */

void str_reverse(char *s)
{
    size_t length;
    char *left;
    char *right;
    char temp;

    length = my_strlen(s);

    if (length < 2)
    {
        return;
    }

    left = s;
    right = s + length - 1;

    while (left < right)
    {
        temp = *left;
        *left = *right;
        *right = temp;

        left++;
        right--;
    }
}


/* =====================================================
   FUNCTION 3: STR_COMPARE_CI
   ===================================================== */

int str_compare_ci(const char *a, const char *b)
{
    char ca;
    char cb;

    while (*a != '\0' && *b != '\0')
    {
        ca = my_lower(*a);
        cb = my_lower(*b);

        if (ca < cb)
        {
            return -1;
        }

        if (ca > cb)
        {
            return 1;
        }

        a++;
        b++;
    }

    if (*a == '\0' && *b == '\0')
    {
        return 0;
    }

    if (*a == '\0')
    {
        return -1;
    }

    return 1;
}


/* =====================================================
   FUNCTION 4: STR_COPY_BOUNDED
   ===================================================== */

size_t str_copy_bounded(char *dst, const char *src, size_t size)
{
    size_t length;
    size_t i;

    length = my_strlen(src);

    if (size == 0)
    {
        return length;
    }

    i = 0;

    while (i < size - 1 && src[i] != '\0')
    {
        dst[i] = src[i];
        i++;
    }

    dst[i] = '\0';

    return length;
}


/* =====================================================
   FUNCTION 5: STR_FIND_SUB
   ===================================================== */

const char *str_find_sub(const char *hay, const char *needle)
{
    const char *h;

    if (*needle == '\0')
    {
        return hay;
    }

    h = hay;

    while (*h != '\0')
    {
        if (matches_at(h, needle))
        {
            return h;
        }

        h++;
    }

    return NULL;
}


/* =====================================================
   FUNCTION 6: STR_SQUEEZE
   ===================================================== */

size_t str_squeeze(char *s)
{
    char *read;
    char *write;
    int pending_space;

    read = s;
    write = s;
    pending_space = 0;

    /* Remove leading spaces and tabs */
    while (*read == ' ' || *read == '\t')
    {
        read++;
    }

    while (*read != '\0')
    {
        if (*read == ' ' || *read == '\t')
        {
            pending_space = 1;
        }
        else
        {
            if (pending_space && write > s)
            {
                *write = ' ';
                write++;
            }

            *write = *read;
            write++;

            pending_space = 0;
        }

        read++;
    }

    *write = '\0';

    return (size_t)(write - s);
}


/* =====================================================
   FUNCTION 7: STR_SPLIT
   ===================================================== */

int str_split(char *s, char delim, char *fields[], int max_fields)
{
    int total_fields;
    char *p;

    total_fields = 1;

    if (max_fields > 0)
    {
        fields[0] = s;
    }

    p = s;

    while (*p != '\0')
    {
        if (*p == delim)
        {
            *p = '\0';

            total_fields++;

            if (total_fields <= max_fields)
            {
                fields[total_fields - 1] = p + 1;
            }
        }

        p++;
    }

    return total_fields;
}


/* =====================================================
   MAIN FUNCTION: TEST ALL SEVEN FUNCTIONS
   ===================================================== */

int main(void)
{
    const char *s;
    const char *p;
    const char *hay;

    // char a[100];
    // char b[100];
    char destination[4];
    char destination2[1];
    char zero_test[2];

    char squeeze1[100];
    char squeeze2[100];
    char squeeze3[100];
    char squeeze4[100];

    char split1[100];
    char split2[100];
    char split3[100];
    char split4[100];

    char *fields[5];

    size_t result;
    size_t new_length;
    int total;

    printf("\n====================================\n");
    printf("   STRING LIBRARY - ASSIGNMENT 2\n");
    printf("   DUSHIMIMANA Emmanuel\n");
    printf("   ID: 20251SEN201\n");
    printf("====================================\n");


    /* TEST 1: STR_FIND_CHAR */

    printf("\n===== TEST 1: FIND CHARACTER =====\n");

    s = "hello";

    p = str_find_char(s, 'l');

    printf("Find l: %s (Expected: llo)\n",
           p ? p : "NULL");

    p = str_find_char(s, 'z');

    printf("Find z: %s (Expected: NULL)\n",
           p ? p : "NULL");

    p = str_find_char(s, '\0');

    printf("Find null: %s (Expected: EMPTY)\n",
           p && *p == '\0' ? "EMPTY" : "WRONG");

    p = str_find_char("", 'a');

    printf("Empty string: %s (Expected: NULL)\n",
           p ? "FOUND" : "NULL");


    /* TEST 2: STR_REVERSE */

    printf("\n===== TEST 2: REVERSE =====\n");

    // strcpy_test:
    {
        char reverse1[] = "hello";
        char reverse2[] = "ab";
        char reverse3[] = "";
        char reverse4[] = "racecar";

        str_reverse(reverse1);
        str_reverse(reverse2);
        str_reverse(reverse3);
        str_reverse(reverse4);

        printf("hello: %s (Expected: olleh)\n", reverse1);
        printf("ab: %s (Expected: ba)\n", reverse2);
        printf("empty: '%s' (Expected: '')\n", reverse3);
        printf("racecar: %s (Expected: racecar)\n", reverse4);
    }


    /* TEST 3: STR_COMPARE_CI */

    printf("\n===== TEST 3: COMPARE =====\n");

    printf("Hello/hello: %d (Expected: 0)\n",
           str_compare_ci("Hello", "hello"));

    printf("apple/Banana: %d (Expected: -1)\n",
           str_compare_ci("apple", "Banana"));

    printf("Zebra/apple: %d (Expected: 1)\n",
           str_compare_ci("Zebra", "apple"));

    printf("abc/ab: %d (Expected: 1)\n",
           str_compare_ci("abc", "ab"));

    printf("AB/abc: %d (Expected: -1)\n",
           str_compare_ci("AB", "abc"));

    printf("empty/empty: %d (Expected: 0)\n",
           str_compare_ci("", ""));

    printf("a_b/aBb: %d (Expected: -1)\n",
           str_compare_ci("a_b", "aBb"));


    /* TEST 4: STR_COPY_BOUNDED */

    printf("\n===== TEST 4: BOUNDED COPY =====\n");

    result = str_copy_bounded(destination, "hello", 4);

    printf("Destination: %s (Expected: hel)\n", destination);
    printf("Length: %lu (Expected: 5)\n",
           (unsigned long)result);

    result = str_copy_bounded(destination2, "hello", 1);

    printf("Size 1: '%s' (Expected: '')\n", destination2);
    printf("Length: %lu (Expected: 5)\n",
           (unsigned long)result);

    zero_test[0] = 'X';
    zero_test[1] = 'Y';

    result = str_copy_bounded(zero_test, "hello", 0);

    printf("Size 0 length: %lu (Expected: 5)\n",
           (unsigned long)result);

    printf("Unchanged: %c%c (Expected: XY)\n",
           zero_test[0], zero_test[1]);


    /* TEST 5: STR_FIND_SUB */

    printf("\n===== TEST 5: FIND SUBSTRING =====\n");

    hay = "hello world";

    p = str_find_sub(hay, "world");

    printf("Find world: %s (Expected: world)\n",
           p ? p : "NULL");

    p = str_find_sub(hay, "World");

    printf("Find World: %s (Expected: NULL)\n",
           p ? "FOUND" : "NULL");

    p = str_find_sub("aaab", "aab");

    printf("Overlap: %s (Expected: aab)\n",
           p ? p : "NULL");

    p = str_find_sub(hay, "");

    printf("Empty needle: %s (Expected: START)\n",
           p == hay ? "START" : "WRONG");


    /* TEST 6: STR_SQUEEZE */

    printf("\n===== TEST 6: SQUEEZE =====\n");

    {
        char input1[] = "  hello   world  ";
        char input2[] = "a\t\tb";
        char input3[] = "   ";
        char input4[] = "a  \n  b";

        my_strlen("test");

        /* Copy test data into writable arrays */
        {
            size_t i;

            i = 0;
            while (input1[i] != '\0')
            {
                squeeze1[i] = input1[i];
                i++;
            }
            squeeze1[i] = '\0';

            i = 0;
            while (input2[i] != '\0')
            {
                squeeze2[i] = input2[i];
                i++;
            }
            squeeze2[i] = '\0';

            i = 0;
            while (input3[i] != '\0')
            {
                squeeze3[i] = input3[i];
                i++;
            }
            squeeze3[i] = '\0';

            i = 0;
            while (input4[i] != '\0')
            {
                squeeze4[i] = input4[i];
                i++;
            }
            squeeze4[i] = '\0';
        }
    }

    new_length = str_squeeze(squeeze1);
    printf("Result: '%s' (Expected: hello world)\n", squeeze1);
    printf("Length: %lu (Expected: 11)\n",
           (unsigned long)new_length);

    new_length = str_squeeze(squeeze2);
    printf("Tabs: '%s' (Expected: a b)\n", squeeze2);

    new_length = str_squeeze(squeeze3);
    printf("Spaces: '%s' (Expected: empty)\n", squeeze3);
    printf("Length: %lu (Expected: 0)\n",
           (unsigned long)new_length);

    new_length = str_squeeze(squeeze4);
    printf("Newline test: '%s' (Expected: a \\n b)\n", squeeze4);


    /* TEST 7: STR_SPLIT */

    printf("\n===== TEST 7: SPLIT =====\n");

    {
        char original[] = "red,green,blue";
        size_t i;

        i = 0;
        while (original[i] != '\0')
        {
            split1[i] = original[i];
            i++;
        }
        split1[i] = '\0';
    }

    total = str_split(split1, ',', fields, 5);

    printf("Total fields: %d (Expected: 3)\n", total);
    printf("Field 1: %s (Expected: red)\n", fields[0]);
    printf("Field 2: %s (Expected: green)\n", fields[1]);
    printf("Field 3: %s (Expected: blue)\n", fields[2]);


    {
        char original[] = "a,,b";
        size_t i;

        i = 0;
        while (original[i] != '\0')
        {
            split2[i] = original[i];
            i++;
        }
        split2[i] = '\0';
    }

    total = str_split(split2, ',', fields, 5);

    printf("\nEmpty fields test:\n");
    printf("Field 1: '%s'\n", fields[0]);
    printf("Field 2: '%s'\n", fields[1]);
    printf("Field 3: '%s'\n", fields[2]);
    printf("Total: %d (Expected: 3)\n", total);


    {
        char original[] = ",a,";
        size_t i;

        i = 0;
        while (original[i] != '\0')
        {
            split3[i] = original[i];
            i++;
        }
        split3[i] = '\0';
    }

    total = str_split(split3, ',', fields, 5);

    printf("\nBoundary fields test:\n");
    printf("Field 1: '%s'\n", fields[0]);
    printf("Field 2: '%s'\n", fields[1]);
    printf("Field 3: '%s'\n", fields[2]);
    printf("Total: %d (Expected: 3)\n", total);


    {
        char original[] = "w,x,y,z";
        size_t i;

        i = 0;
        while (original[i] != '\0')
        {
            split4[i] = original[i];
            i++;
        }
        split4[i] = '\0';
    }

    total = str_split(split4, ',', fields, 2);

    printf("\nLimited fields test:\n");
    printf("Total: %d (Expected: 4)\n", total);
    printf("Field 1: %s (Expected: w)\n", fields[0]);
    printf("Field 2: %s (Expected: x)\n", fields[1]);


    /* FINISH */

    printf("\n====================================\n");
    printf("       ALL TESTS COMPLETED\n");
    printf("====================================\n");

    return 0;
}

